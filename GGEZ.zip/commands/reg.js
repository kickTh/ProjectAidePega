const { SlashCommandBuilder } = require('@discordjs/builders');
const { Modal, TextInputComponent, showModal } = require('discord-modals')
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
    .setName("reg")
    .setDescription("GG EZ"),
    async execute(client, interaction) {
        const regmodal = new Modal()
        .setCustomId("reg-id")
        .setTitle("ลงทะเบียนสมาชิก")
        .addComponents(
            new TextInputComponent()
            .setCustomId("reg-username")
            .setLabel("ชื่อผู้ใช้ | Username")
            .setStyle("SHORT")
            .setRequired(true),
            new TextInputComponent()
            .setCustomId("reg-password")
            .setLabel("รหัสผ่าน | Password")
            .setStyle("SHORT")
            .setRequired(true)
        )
        await showModal(regmodal, {
            client: client,
            interaction: interaction,
        });
    }
}