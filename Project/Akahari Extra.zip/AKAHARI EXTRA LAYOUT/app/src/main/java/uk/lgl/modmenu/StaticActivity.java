package uk.lgl.modmenu;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import android.widget.Button;
import android.widget.CompoundButton;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Looper;
import android.os.Bundle;
import android.view.View;
import android.content.DialogInterface;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class StaticActivity {
    private static final String TAG = "Mod Menu";
    public static String cacheDir;
    public static void Start(final Context context) {
        String currentTime = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
        Log.d("timeStamp", currentTime);
        Calendar date = new GregorianCalendar(2029, Calendar.APRIL, 23);
        date.add(Calendar.DAY_OF_WEEK, 0);//28/01/2021
        String expireTime = new SimpleDateFormat("yyyyMMdd").format(date.getTime());
        int intcurrentTime = Integer.parseInt(currentTime);
        int intexpireTime = Integer.parseInt(expireTime);
        if(intcurrentTime >= intexpireTime) {
        Toast.makeText(context,(Html.fromHtml("<b><font color=RED>MOD MENU </font></b><font color=RED>EXPIRE \n PLEASE UPDATE!<b></b></font>")), Toast.LENGTH_SHORT).show();
            String url = "youtube.com/c/aryanjha69";
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("youtube.com/c/aryanjha69"));
            context.startActivity(i);
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        System.exit(0);
                    }
                }, 7150);
        }

        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)) {
            new Handler().postDelayed(new Runnable() {
                    public void run() {
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setTitle(Html.fromHtml("<font color=RED>ALERT!</b></font>"));
                        builder.setMessage("►ARYAN JHA\n►NEP MODS\n►BAD DRC\n►RUDRA MODDER\n►PM MODDER)");
                        builder.setCancelable(false);
                        builder.setPositiveButton(Html.fromHtml("<b><font color=RED>START</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    
                                }
                            });

                        builder.setCancelable(false);
                        builder.setNegativeButton(Html.fromHtml("<b><font color=RED>OBB LINK</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    Uri uri = Uri.parse("https://t.me/aryanmodvip");
                                    Intent intent = new Intent(
                                        Intent.ACTION_VIEW, uri);
                                    startActivity(intent);
                                    String url = "https://t.me/aryanmodvip";
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(url));
                                    context.startActivity(i);
                                }
                                private void startActivity(Intent intent) {
                                }
                            });

                        builder.setCancelable(false);
                        builder.setNeutralButton(Html.fromHtml("<b><font color=RED>YOUTUBE</font>"), new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int which) {
                                    Uri uri = Uri.parse("https://t.me/aryanmodvip");
                                    Intent intent = new Intent(
                                        Intent.ACTION_VIEW, uri);
                                    startActivity(intent);
                                    String url = "youtube.com/c/aryanjha69";
                                    Intent i = new Intent(Intent.ACTION_VIEW);
                                    i.setData(Uri.parse(url));
                                    context.startActivity(i);
                                }
                                private void startActivity(Intent intent) {
                                }
                            });


                        context.startService(new Intent(context, FloatingModMenuService.class));
                    }
                }, 1800);
        } else {
            context.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + context.getPackageName())));
            Process.killProcess(Process.myPid());
        }
    }

    private static void writeToFile(String name, String base64) {
        File file = new File(cacheDir + name);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(file);
            byte[] decode = Base64.decode(base64, 0);
            fos.write(decode);
            fos.close();
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }
}




