package uk.lgl.modmenu;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;
import uk.lgl.modmenu.ESPView;


import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import android.graphics.drawable.Drawable;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import java.io.InputStream;

public class FloatingModMenuService extends Service {
    private MediaPlayer FXPlayer;
    public View mFloatingView;
    private ImageView ffid,CLOSEBAD,MINIMIZE;
	private TextView username;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
	private ImageView closeimage;
    private LinearLayout view1;
    private LinearLayout view2;
	Button settings ,close,info;
	private LinearLayout CategoryPatches;
    private LinearLayout patches1, patches2, patches3, patches4;
	private LinearLayout Btns;
    private LinearLayout Btns2;
	private ImageView MENUAIM, MENUESP, MENUBRUTAL, MENUOTHER;
    private static final String TAG = "Mod Menu";
	private interface C0518BT {
        void onClick();
    }
	
	public float dipToPixels() {
        return TypedValue.applyDimension(1, 8.0f, getResources().getDisplayMetrics());
    }
	
	//Canvas 
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;
	

    private LinearLayout.LayoutParams hr;
	
	public native void changeToggle(int i);
	
    public static native String Toast();
	
    private native String Title();
	
    private native String Icon();
	
    private native String Icon2();
	
    private native boolean EnableSounds();
	
    private native int IconSize();
	
    public native void Changes(int feature, int value);
	
    private native String[] getFeatureList();
	
	private String expire;
	private String Credits(){
        return "Dias Restantes: " +expire;
    }
	
	
	private String Heading(){
        return "";
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
	
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }
	
	
	public void onCreate() {
        super.onCreate();
        System.loadLibrary("FFH4X");
		this.overlayView = new ESPView((Context)this);
        initFloating();
		DrawCanvas();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    Thread();
                    handler.postDelayed(this, 1000);
                }
            });
    }

    public WindowManager.LayoutParams setParams() {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1);
        params.gravity = 16;
        params.flags = 8192;
        return params;
    }
	

	

    //Here we write the code for our Menu
    private void initFloating() {
        this.rootFrame = new FrameLayout(this);
        this.mRootContainer = new RelativeLayout(this);
        this.mCollapsed = new RelativeLayout(this);
        this.mExpanded = new LinearLayout(this);
        this.view1 = new LinearLayout(this);
		Context paramContext = getBaseContext();
		float scale = getBaseContext().getResources().getDisplayMetrics().density;
        CategoryPatches = new LinearLayout(getBaseContext());
        patches1 = new LinearLayout(getBaseContext());	
		patches2 = new LinearLayout(getBaseContext());
		patches3 = new LinearLayout(getBaseContext());
		patches4 = new LinearLayout(getBaseContext());
        this.view2 = new LinearLayout(this);
		Btns = new LinearLayout(getBaseContext());
        Btns2 = new LinearLayout(getBaseContext());
		AssetManager assetManager = getAssets();
        this.mButtonPanel = new LinearLayout(this);


        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close2 = null;
        try {
            inputStream_close2 = assetManager.open("Aryan_X.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close2 = Drawable.createFromStream(inputStream_close2, null);
        startimage.setImageDrawable(ic_close2);
        startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
		//RelativeLayout.LayoutParams layoutExpanded_LayoutParams = new RelativeLayout.LayoutParams(-2, -2);
        mExpanded.setVisibility(View.GONE);
        mExpanded.setBackgroundColor(Color.parseColor("#000000"));
        mExpanded.getBackground().setAlpha(150);
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(0, 0, 0, 0);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(240), -2));
        android.graphics.drawable.GradientDrawable GIDDGID = new android.graphics.drawable.GradientDrawable();
        int GIDDGIDADD[] = new int[]{ Color.argb(255,255,0,0), Color.argb(255,0,0,0) };
        GIDDGID.setColors(GIDDGIDADD);
        GIDDGID.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TL_BR);
        GIDDGID.setCornerRadii(new float[] { 5, 5, 5, 5, 5, 5, 5, 5 });
        android.graphics.drawable.RippleDrawable GIDDGID_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), GIDDGID, null);
        mExpanded.setBackground(GIDDGID_RE);
        if(Build.VERSION.SDK_INT >= 21) { mExpanded.setElevation(100f); }
		
		LinearLayout PSLayoutTop = new LinearLayout(this);
        PSLayoutTop.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        PSLayoutTop.setOrientation(2);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
        LinearLayout PSLayout = new LinearLayout(this);
        PSLayout.setGravity(Gravity.CENTER);
        PSLayout.setLayoutParams(new LinearLayout.LayoutParams(layoutParams.FILL_PARENT, -1));
		
		
		LinearLayout option = new LinearLayout(this);
        option.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(150)));
        option.setPadding(0, 0, 10, 0);
        option.setOrientation(LinearLayout.HORIZONTAL);
        option.setGravity(17);
	    option.setBackgroundColor(Color.parseColor("#000000"));

		LinearLayout outeroption = new LinearLayout(this);
        outeroption.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(150)));
        outeroption.setPadding(0, 0, 0, 0);
        outeroption.setOrientation(LinearLayout.VERTICAL);
        outeroption.setGravity(17);
        outeroption.setBackgroundColor(Color.parseColor("#000000"));

		LinearLayout outeroption2 = new LinearLayout(this);
        outeroption2.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(140)));
        outeroption2.setPadding(0, 0, 0, 0);
        outeroption2.setOrientation(LinearLayout.VERTICAL);
        outeroption2.setGravity(17);
	    outeroption2.setBackgroundColor(Color.parseColor("#000000"));


		final ScrollView CategoryScroll = new ScrollView(getBaseContext());
        CategoryScroll.setLayoutParams(new LinearLayout.LayoutParams(dp(50), dp(150)));

		final ScrollView scrollView1 = new ScrollView(getBaseContext());
        scrollView1.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));

		final ScrollView scrollView2 = new ScrollView(getBaseContext());
        scrollView2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

		final ScrollView scrollView3 = new ScrollView(getBaseContext());
        scrollView3.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

		final ScrollView scrollView4 = new ScrollView(getBaseContext());
        scrollView4.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

		CategoryPatches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        CategoryPatches.setOrientation(LinearLayout.VERTICAL);
        patches1.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches1.setOrientation(LinearLayout.VERTICAL);
		patches2.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches2.setOrientation(LinearLayout.VERTICAL);
		patches3.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches3.setOrientation(LinearLayout.VERTICAL);
		patches4.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches4.setOrientation(LinearLayout.VERTICAL);
		
        this.hr = new LinearLayout.LayoutParams(-1, -1);
        this.hr.setMargins(0, 0, 0, 5);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));


		//BUTTON CLOSE
		RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(0, 0, 0, 0);
        relativeLayout.setVerticalGravity(16);
		relativeLayout.setBackgroundColor(Color.BLACK);
        close = new Button(this);
        close.setBackgroundColor(Color.parseColor("#000000"));
        close.setText("CLOSE");
        close.setTextColor(Color.parseColor("WHITE"));
        close.setLayoutParams(new RelativeLayout.LayoutParams(170, dp(35)));
        close.setTypeface(null, Typeface.BOLD_ITALIC);
        android.graphics.drawable.GradientDrawable BEBCBGD = new android.graphics.drawable.GradientDrawable();
        int BEBCBGDADD[] = new int[]{ Color.argb(255,255,0,0), Color.argb(255,255,0,0) };
        BEBCBGD.setColors(BEBCBGDADD);
        BEBCBGD.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TR_BL);
        android.graphics.drawable.RippleDrawable BEBCBGD_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), BEBCBGD, null);
        close.setBackground(BEBCBGD_RE);
        if(Build.VERSION.SDK_INT >= 21) { close.setElevation(100f); }
		RelativeLayout.LayoutParams relativeparams = new RelativeLayout.LayoutParams(170, dp(35));
		relativeparams.addRule(11);
		info = new Button(this);
        info.setBackgroundColor(Color.parseColor("#000000"));
        info.setText("INFO");
        info.setTextColor(Color.parseColor("WHITE"));
        info.setLayoutParams(relativeparams);
        info.setTypeface(null, Typeface.BOLD_ITALIC);
        android.graphics.drawable.GradientDrawable BEBCBGDD = new android.graphics.drawable.GradientDrawable();
        int BEBCBGDADDD[] = new int[]{ Color.argb(255,255,0,0), Color.argb(255,255,0,0) };
        BEBCBGDD.setColors(BEBCBGDADDD);
        BEBCBGDD.setOrientation(android.graphics.drawable.GradientDrawable.Orientation.TR_BL);
        android.graphics.drawable.RippleDrawable BEBCBGDD_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.argb(84,0,255,255)}), BEBCBGDD, null);
        info.setBackground(BEBCBGDD_RE);
		
		TextView nomeJogoVersao = new TextView(this);
        nomeJogoVersao.setText("Free Fire v1.67");
        nomeJogoVersao.setTextColor(Color.WHITE);
        nomeJogoVersao.setTextSize(14.0f);
        nomeJogoVersao.setHeight(60);
        nomeJogoVersao.setGravity(17);
        nomeJogoVersao.setTypeface(Typeface.MONOSPACE);
		
        this.ffid = new ImageView(this);
		RelativeLayout.LayoutParams ffid_LayoutParams = new RelativeLayout.LayoutParams(-5, -3);
        this.ffid.setLayoutParams(new RelativeLayout.LayoutParams(-5, -3));
		ffid_LayoutParams.width = (int) ((50.0f * scale) + 0.5f);
        ffid_LayoutParams.height = (int) ((50.0f * scale) + 0.5f);
        ffid_LayoutParams.addRule(21, -1);
        ffid_LayoutParams.setMarginEnd((int) ((200.0f * scale) + 0.7f));
        this.ffid.getLayoutParams().height = dp(35);
        this.ffid.getLayoutParams().width = dp(75);
        this.ffid.requestLayout();
        this.ffid.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close3 = null;
        try {
            inputStream_close3 = assetManager.open("Aryan_Xd.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close3 = Drawable.createFromStream(inputStream_close3, null);
        ffid.setImageDrawable(ic_close3);
        ((ViewGroup.MarginLayoutParams) this.ffid.getLayoutParams()).leftMargin = convertDipToPixels(5);
		
		
		//Image Close Exit
		closeimage = new ImageView(getBaseContext());
        closeimage.setLayoutParams(new RelativeLayout.LayoutParams(-3, -8));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(5);
        int dimensionClose = 23;
        int dimensionInDpClose = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dimensionClose, getResources().getDisplayMetrics());
        closeimage.getLayoutParams().height = dimensionInDpClose;
        closeimage.getLayoutParams().width = dimensionInDpClose;
        closeimage.requestLayout();
        InputStream inputStream_close = null;
        try {
            inputStream_close = assetManager.open("Aryan_JHA.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close = Drawable.createFromStream(inputStream_close, null);
        closeimage.setImageDrawable(ic_close);
        closeimage.setAlpha(220);
        ((ViewGroup.MarginLayoutParams) closeimage.getLayoutParams()).leftMargin = (40);
        ((ViewGroup.MarginLayoutParams) closeimage.getLayoutParams()).leftMargin = convertDipToPixels(55);
		
		

		this.username = new TextView(this);
        RelativeLayout.LayoutParams username_LayoutParams = new RelativeLayout.LayoutParams(-9, -9);
        username_LayoutParams.width = (int) ((300.0f * scale) + 0.10f);
        Context context = paramContext;
        username_LayoutParams.addRule(20, -1);
        username_LayoutParams.topMargin = (int) ((300.0f * scale) + 0.10f);
        username_LayoutParams.setMarginEnd((int) ((300.0f * scale) + 0.10f));
        this.username.setAllCaps(true);
        this.username.setTextColor(Color.parseColor("#000000"));
        this.username.setLayoutParams(username_LayoutParams);
		this.username.setText("ARYAN JHA\nARYAN JHA");
        this.username.setGravity(30);
		username.setLayoutParams(new LinearLayout.LayoutParams(dp(100), dp(150)));
		this.username.setPadding(0, 0, 0, 10);
		this.username.setLayoutParams(layoutParams);
		
       // relativeLayout.addView(this.ffid);
		//relativeLayout.addView(this.username);

		
		RelativeLayout titleText = new RelativeLayout(this);
        titleText.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        titleText.setPadding(0, 0, 0, 0);
        titleText.setVerticalGravity(16);
        this.CLOSEBAD = new ImageView(this);
        RelativeLayout.LayoutParams CLOSEBAD_LayoutParams = new RelativeLayout.LayoutParams(-5, -3);
        this.CLOSEBAD.setLayoutParams(new RelativeLayout.LayoutParams(-5, -3));
        CLOSEBAD_LayoutParams.width = (int) ((50.0f * scale) + 0.5f);
        CLOSEBAD_LayoutParams.height = (int) ((50.0f * scale) + 0.5f);
        CLOSEBAD_LayoutParams.addRule(21, -1);
        CLOSEBAD_LayoutParams.setMarginEnd((int) ((200.0f * scale) + 0.7f));
        this.CLOSEBAD.getLayoutParams().height = dp(30);
        this.CLOSEBAD.getLayoutParams().width = dp(30);
        this.CLOSEBAD.requestLayout();
        this.CLOSEBAD.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close33 = null;
        try {
            inputStream_close33 = assetManager.open("ARYAN_JHA/close.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close33 = Drawable.createFromStream(inputStream_close33, null);
        CLOSEBAD.setImageDrawable(ic_close33);
        ((ViewGroup.MarginLayoutParams)
        this.CLOSEBAD.getLayoutParams()).leftMargin = convertDipToPixels(5);
        RelativeLayout.LayoutParams rlz = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlz.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        CLOSEBAD.setLayoutParams(rlz);
        
        RelativeLayout.LayoutParams layoutParamsA = new RelativeLayout.LayoutParams(dp(60), dp(27));
        layoutParamsA.addRule(11);
        

        TextView textView2 = new TextView(this);
        textView2.setText(Html.fromHtml("<font face='serif'>" +"ARYAN JHA"+ "</font>"));
        textView2.setTypeface((Typeface) null, 1);
        textView2.setTextColor(Color.WHITE);
        textView2.setTextSize(22.54f);
        textView2.setPadding(0, 0, 0, 0); 
       
        RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        textView2.setLayoutParams(rl);

		this.Btns2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.Btns2.setBackgroundColor(Color.BLACK);
        this.Btns2.setGravity(17);
        this.Btns2.setPadding(0, 0, 5, 0);
        this.Btns2.setOrientation(LinearLayout.HORIZONTAL);
        this.Btns.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        this.Btns.setBackgroundColor(Color.BLACK);
        this.Btns.setGravity(6);
        this.Btns.setPadding(0, 0, 5, 0);
        this.Btns.setOrientation(LinearLayout.HORIZONTAL);
        GradientDrawable DCCEEC = new GradientDrawable();
        DCCEEC.setStroke(1, Color.parseColor("#FF0000"));
      //  infoView.setBackground(DCCEEC);
		
        TextView textView = new TextView(getBaseContext());
        textView.setText("DARKSIDE");
        textView.setTextColor(Color.WHITE);
        textView.setBackgroundColor(Color.TRANSPARENT);
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setTextSize(20.0f);
        textView.setGravity(17);
        textView.setPadding(0, 15, 0, 0);
		
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -1);
        layoutParams2.gravity = 17;
		
        TextView textView0 = new TextView(getBaseContext());
        textView0.setText(Html.fromHtml("<font color='WHITE'>Status : </font>" + Build.USER)); 
        textView0.setTextSize(12.0f);
        textView0.setPadding(5, 0, 0, 1);
        textView0.setTypeface(Typeface.MONOSPACE);
        textView0.setGravity(Gravity.LEFT);
        textView0.setTextColor(Color.WHITE);
		
        TextView textView3 = new TextView(getBaseContext());
        textView3.setText(Html.fromHtml("<font color='WHITE'>Model : </font>" + Build.BRAND)); 
        textView3.setTextSize(12.0f);
        textView3.setPadding(5, 0, 0, 5);
        textView3.setTypeface(Typeface.MONOSPACE);
        textView3.setGravity(Gravity.LEFT);
        textView3.setTextColor(Color.WHITE);
		
		
        settings = new Button(this);
        settings.setPadding(0, 5, 0, 5);
		settings.setLayoutParams(layoutParams);
		layoutParams.bottomMargin = dp(2);
		layoutParams.rightMargin =  dp(2);
        settings.setBackgroundColor(Color.rgb(0,116,186));
        settings.setText("CLOSE");  
		settings.setTextColor(-1);
		settings.setTypeface(null,Typeface.NORMAL);    
        settings.setTextSize(15.0f);
        settings.setGravity(17);
        android.graphics.drawable.GradientDrawable
		DFIABBIf2 = new android.graphics.drawable.GradientDrawable();
        DFIABBIf2.setColor(0);
        DFIABBIf2.setCornerRadius(10);
        DFIABBIf2.setStroke(2, -1);
        settings.setBackground(DFIABBIf2);
        settings.setLayoutParams(layoutParamsA);
		
		MENUAIM = new ImageView(this);
        final LinearLayout.LayoutParams CATEAIM = new LinearLayout.LayoutParams(dp(40), dp(40));
		CATEAIM.setMargins(8, 8, 8, 8);
        MENUAIM.setLayoutParams(CATEAIM);
		MENUAIM.setPadding( 5, 5, 5, 5);
		MENUAIM.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode1 = Base64.decode(Categorybad.Aimbot, 0);
        MENUAIM.setImageBitmap(BitmapFactory.decodeByteArray(decode1, 0, decode1.length));
	    MENUAIM.setBackgroundColor(Color.parseColor("#FF0000"));

		MENUAIM.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					MENUAIM.setBackgroundColor(Color.parseColor("#FF0000"));
					MENUESP.setBackgroundColor(Color.parseColor("#000000"));
					MENUBRUTAL.setBackgroundColor(Color.parseColor("#000000"));
					MENUOTHER.setBackgroundColor(Color.parseColor("#000000"));
					scrollView1.setVisibility(View.VISIBLE);
					scrollView2.setVisibility(View.GONE);
					scrollView3.setVisibility(View.GONE);
					scrollView4.setVisibility(View.GONE);

				}				    
			});

		CategoryPatches.addView(MENUAIM);

	    MENUESP = new ImageView(this);
        final LinearLayout.LayoutParams CATEESP = new LinearLayout.LayoutParams(dp(40), dp(40));
		CATEESP.setMargins(8, 8, 8, 8);
        MENUESP.setLayoutParams(CATEESP);
		MENUESP.setPadding( 5, 5, 5, 5);
		MENUESP.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode2 = Base64.decode(Categorybad.Esp, 0);
        MENUESP.setImageBitmap(BitmapFactory.decodeByteArray(decode2, 0, decode2.length));
	    MENUESP.setBackgroundColor(Color.parseColor("#000000"));

		MENUESP.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					MENUAIM.setBackgroundColor(Color.parseColor("#000000"));
					MENUESP.setBackgroundColor(Color.parseColor("#FF0000"));
					MENUBRUTAL.setBackgroundColor(Color.parseColor("#000000"));
					MENUOTHER.setBackgroundColor(Color.parseColor("#000000"));
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.VISIBLE);
					scrollView3.setVisibility(View.GONE);
					scrollView4.setVisibility(View.GONE);

				}				    
			});

		CategoryPatches.addView(MENUESP);

		MENUBRUTAL = new ImageView(this);
        final LinearLayout.LayoutParams CATEBRUTAL = new LinearLayout.LayoutParams(dp(40), dp(40));
		CATEBRUTAL.setMargins(8, 8, 8, 8);
        MENUBRUTAL.setLayoutParams(CATEBRUTAL);
		MENUBRUTAL.setPadding( 5, 5, 5, 5);
		MENUBRUTAL.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode3 = Base64.decode(Categorybad.Brutal, 0);
        MENUBRUTAL.setImageBitmap(BitmapFactory.decodeByteArray(decode3, 0, decode3.length));
	    MENUBRUTAL.setBackgroundColor(Color.parseColor("#000000"));

		MENUBRUTAL.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					MENUAIM.setBackgroundColor(Color.parseColor("#000000"));
					MENUESP.setBackgroundColor(Color.parseColor("#000000"));
					MENUBRUTAL.setBackgroundColor(Color.parseColor("#FF0000"));
					MENUOTHER.setBackgroundColor(Color.parseColor("#000000"));
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.GONE);
					scrollView3.setVisibility(View.VISIBLE);
					scrollView4.setVisibility(View.GONE);

				}				    
			});

		CategoryPatches.addView(MENUBRUTAL);

		MENUOTHER = new ImageView(this);
        final LinearLayout.LayoutParams CATEOTHER = new LinearLayout.LayoutParams(dp(40), dp(40));
		CATEOTHER.setMargins(8, 8, 8, 8);
        MENUOTHER.setLayoutParams(CATEOTHER);
		MENUOTHER.setPadding( 5, 5, 5, 5);
        MENUOTHER.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode4 = Base64.decode(Categorybad.Setting, 0);
        MENUOTHER.setImageBitmap(BitmapFactory.decodeByteArray(decode4, 0, decode4.length));
	    MENUOTHER.setBackgroundColor(Color.parseColor("#000000"));

		MENUOTHER.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v){
					MENUAIM.setBackgroundColor(Color.parseColor("#000000"));
					MENUESP.setBackgroundColor(Color.parseColor("#000000"));
					MENUBRUTAL.setBackgroundColor(Color.parseColor("#000000"));
					MENUOTHER.setBackgroundColor(Color.parseColor("#FF0000"));
					scrollView1.setVisibility(View.GONE);
					scrollView2.setVisibility(View.GONE);
					scrollView3.setVisibility(View.GONE);
					scrollView4.setVisibility(View.VISIBLE);
				}
			});
		CategoryPatches.addView(MENUOTHER);
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
		
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(startimage);
		//mCollapsed.addView(closeimage);

        mExpanded.addView(PSLayoutTop);
        PSLayoutTop.addView(PSLayout);
		PSLayout.addView(textView);
        mExpanded.addView(textView0);
        mExpanded.addView(textView3);
        mExpanded.addView(option);
        option.addView(outeroption);
		option.addView(outeroption2);
		outeroption.addView(CategoryScroll);
		outeroption2.addView(scrollView1);
		outeroption2.addView(scrollView2);
		outeroption2.addView(scrollView3);
		outeroption2.addView(scrollView4);
		CategoryScroll.addView(CategoryPatches);
		scrollView1.addView(patches1);
		scrollView2.addView(patches2);
		scrollView3.addView(patches3);
		scrollView4.addView(patches4);
		this.mExpanded.addView(this.Btns2);
        this.Btns2.addView(nomeJogoVersao);
        mExpanded.addView(relativeLayout);
		relativeLayout.addView(this.close);
        relativeLayout.addView(info);
		
        mFloatingView = rootFrame;
		
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());

        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

						if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }


	private boolean hide = false;
	
	private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.GONE);
                    view3.setVisibility(View.VISIBLE);

                }
            });
		
		close.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.VISIBLE);
                    view2.setAlpha(0.95f);
                    view3.setVisibility(View.GONE);

                }
            });
            
		

    }
		
    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {

                addSwitch(str.replace("TG_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
			} else if (str.contains("TG2_")) {

					addSwitch2(str.replace("TG2_", ""), new InterfaceBool() {
							public void OnWrite(boolean z) {
								Changes(feature, 0);
							}
						});
			} else if (str.contains("TG3_")) {

				addSwitch3(str.replace("TG3_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
			} else if (str.contains("TG4_")) {

				addSwitch4(str.replace("TG4_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
			} else if (str.contains("SB_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("SB2_")) {
                String[] split = str.split("_");
                addSeekBar2(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("SBP_")) {
                String[] split = str.split("_");
				addSeekBarSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("SBCor_")) {
                String[] split = str.split("_");
				addEspCor(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
			} else if (str.contains("CH_")) {
                addCategory(str.replace("CH_", ""));
			} else if (str.contains("CT_")) {
                addCategory2(str.replace("CT_", ""));
            } else if (str.contains("SeekBar_")) {
			} else if (str.contains("SB_")) {
                
                        
                   

            }
        }
    }
	private void addCategory(String text) {
        Button textView = new Button(this);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.BLACK);
        textView.setPadding(10, 5, 10, 5);
        //patches.addView(textView);
    }


	private void addCategory2(String text) {
        TextView textView = new TextView(this);
		textView.setText(text);
        textView.setTextSize(dipToPixels());
		textView.setTextSize(15.0f);
		textView.setTextColor(Color.RED);
		textView.setLayoutParams(setParams());
		// patches.addView(textView);
    }



	private void addSwitch(String string2, final  InterfaceBool interfaceBool) {
        final GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(50);
        f.setSize(dp(10),dp(1));
        f.setAlpha(50);
        f.setColor(Color.WHITE);      
        final Switch sw = new Switch(this);
        GradientDrawable g= new  GradientDrawable();
        g.setSize(50,50);
        g.setShape(1);
        g.setStroke(3,Color.RED);
        g.setColor(Color.BLACK);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.BLACK);
        gd.setSize(10,4);
        gd.setStroke(2,Color.RED);
        gd.setCornerRadius(100);
        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setTypeface(null, Typeface.BOLD_ITALIC);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(15.0f);
        sw.setBackgroundColor(Color.TRANSPARENT);
        sw.setThumbDrawable(g);
        sw.setTrackDrawable(gd);
        sw.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        sw.setTypeface(sw.getTypeface(), Typeface.NORMAL);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        gd.setColor(Color.RED);

                    } else {
                        gd.setColor(Color.BLACK);
                    }
                }
            });
        patches1.addView(sw);
	}
	private void addSwitch2(String string2, final  InterfaceBool interfaceBool) {
        final GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(50);
        f.setSize(dp(10),dp(1));
        f.setAlpha(50);
        f.setColor(Color.WHITE);      
        final Switch sw = new Switch(this);
        GradientDrawable g= new  GradientDrawable();
        g.setSize(50,50);
        g.setShape(1);
        g.setStroke(3,Color.RED);
        g.setColor(Color.BLACK);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.BLACK);
        gd.setSize(10,4);
        gd.setStroke(2,Color.RED);
        gd.setCornerRadius(100);
        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setTypeface(null, Typeface.BOLD_ITALIC);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(15.0f);
        sw.setBackgroundColor(Color.TRANSPARENT);
        sw.setThumbDrawable(g);
        sw.setTrackDrawable(gd);
        sw.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        sw.setTypeface(sw.getTypeface(), Typeface.NORMAL);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        gd.setColor(Color.RED);

                    } else {
                        gd.setColor(Color.BLACK);
                    }
                }
            });
        patches2.addView(sw);
	}
	
	private void addSwitch3(String string2, final  InterfaceBool interfaceBool) {
        final GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(50);
        f.setSize(dp(10),dp(1));
        f.setAlpha(50);
        f.setColor(Color.WHITE);      
        final Switch sw = new Switch(this);
        GradientDrawable g= new  GradientDrawable();
        g.setSize(50,50);
        g.setShape(1);
        g.setStroke(3,Color.RED);
        g.setColor(Color.BLACK);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.BLACK);
        gd.setSize(10,4);
        gd.setStroke(2,Color.RED);
        gd.setCornerRadius(100);
        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setTypeface(null, Typeface.BOLD_ITALIC);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(15.0f);
        sw.setBackgroundColor(Color.TRANSPARENT);
        sw.setThumbDrawable(g);
        sw.setTrackDrawable(gd);
        sw.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        sw.setTypeface(sw.getTypeface(), Typeface.NORMAL);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        gd.setColor(Color.RED);

                    } else {
                        gd.setColor(Color.BLACK);
                    }
                }
            });
        patches3.addView(sw);
	}
	private void addSwitch4(String string2, final  InterfaceBool interfaceBool) {
        final GradientDrawable f = new GradientDrawable();
        f.setCornerRadius(50);
        f.setSize(dp(10),dp(1));
        f.setAlpha(50);
        f.setColor(Color.WHITE);      
        final Switch sw = new Switch(this);
        GradientDrawable g= new  GradientDrawable();
        g.setSize(50,50);
        g.setShape(1);
        g.setStroke(3,Color.RED);
        g.setColor(Color.BLACK);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.BLACK);
        gd.setSize(10,4);
        gd.setStroke(2,Color.RED);
        gd.setCornerRadius(100);
        sw.setText(string2);
        sw.setTextColor(Color.WHITE);
        sw.setTypeface(null, Typeface.BOLD_ITALIC);
        sw.setPadding(10, 3, 3, 3);
        sw.setTextSize(15.0f);
        sw.setBackgroundColor(Color.TRANSPARENT);
        sw.setThumbDrawable(g);
        sw.setTrackDrawable(gd);
        sw.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        sw.setTypeface(sw.getTypeface(), Typeface.NORMAL);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    interfaceBool.OnWrite(isChecked);
                    if(isChecked) {
                        gd.setColor(Color.RED);

                    } else {
                        gd.setColor(Color.BLACK);
                    }
                }
            });
        patches4.addView(sw);
	}
    private void addSeekBar(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setBackgroundColor(Color.parseColor("#000000"));
        linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + " <font color='RED'>" + "> OFF" + "</font>"));
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbarCircle = new GradientDrawable();
        seekbarCircle.setShape(1);
        seekbarCircle.setColor(Color.BLACK);
        seekbarCircle.setStroke(dp(2), Color.RED);
        seekbarCircle.setCornerRadius(15.0f);
        seekbarCircle.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbarCircle);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("RED"), PorterDuff.Mode.SRC_IN);
        seekBar.setThumb(seekbarCircle);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
                int l;
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + "<font color='RED'>" + " > OFF" + "</font>"));
                        return;
                    }
                    interInt.OnWrite(i);
                    textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + "<font color='RED'>" + " > " + i + "</font>"));
                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches1.addView(linearLayout);
    }

	private void addSeekBar2(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);
        linearLayout.setBackgroundColor(Color.parseColor("#000000"));
        linearLayout.getBackground().setAlpha(1);
        linearLayout.setLayoutParams(layoutParams);
        final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + " <font color='RED'>" + "> OFF" + "</font>"));
        textView.setTypeface(null, Typeface.BOLD_ITALIC);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbarCircle = new GradientDrawable();
        seekbarCircle.setShape(1);
        seekbarCircle.setColor(Color.BLACK);
        seekbarCircle.setStroke(dp(2), Color.RED);
        seekbarCircle.setCornerRadius(15.0f);
        seekbarCircle.setSize(dp(17), dp(17));
        seekBar.setThumb(seekbarCircle);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("RED"), PorterDuff.Mode.SRC_IN);
        seekBar.setThumb(seekbarCircle);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);
        final TextView textView2 = textView;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
                int l;
                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    if (i == 0) {
                        seekBar.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView2;
                        textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + "<font color='RED'>" + " > OFF" + "</font>"));
                        return;
                    }
                    interInt.OnWrite(i);
                    textView.setText(Html.fromHtml("<font face='BOLD_ITALIC'><b>" + feature + "<font color='RED'>" + " > " + i + "</font>"));
                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches2.addView(linearLayout);
    }
	private void addSeekBarSpot(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
		linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));


		final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "Desativado" + "</b></font>"));


        textView.setTextSize(15);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);



        final TextView textView4 = textView;
        final SeekBar seekBar4 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
                    if (i == 0) {
                        seekBar4.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "Desativado" + "</b></font>"));
                    } else if (i == 1) {
                        seekBar4.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "Cabeça" + "</b></font>"));
                    } else if (i == 2) {
                        seekBar4.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "Pescoço" + "</b></font>"));
                    } else if (i == 3) {
                        seekBar4.setProgress(i);
                        interInt.OnWrite(i);
                        TextView textView = textView4;
                        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "Quadril" + "</b></font>"));
                    }
                    interInt.OnWrite(i);
                }
            });

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        patches1.addView(linearLayout);
    }

	private void addEspCor(final String feature, final int prog, int max, final InterfaceInt interInt) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
		linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));


		final TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face='roboto'>" + feature + " : <font color='WHITE'>" + "VERMELHO" + "</b></font>"));


        textView.setTextSize(15);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
		seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(prog);



        final TextView textView4 = textView;
        final SeekBar seekBar4 = seekBar;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar2) {
                }

                public void onStopTrackingTouch(SeekBar seekBar2) {
                }

                int l;

                public void onProgressChanged(SeekBar seekBar2, int i, boolean z) {
					if (i == 0) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "VERMELHO" + "</b></font>"));
					} else if (i == 1) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "VERDE" + "</b></font>"));
					} else if (i == 2) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "AZUL" + "</b></font>"));

					} else if (i == 3) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "ORANGE" + "</b></font>"));


					} else if (i == 4) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "PRETO" + "</b></font>"));


					} else if (i == 5) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "AMARELO" + "</b></font>"));


					} else if (i == 6) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "CYANO" + "</b></font>"));


					} else if (i == 7) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "MAGENTA" + "</b></font>"));


					} else if (i == 8) {
						seekBar2.setProgress(i);
						interInt.OnWrite(i);
						TextView textView = textView4;
						textView.setText(Html.fromHtml("<font face='roboto'>" + feature + ": <font color='WHITE'>" + "BRANCO" + "</b></font>"));


					}
					interInt.OnWrite(i);
				}
			});

		linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        this.patches1.addView(linearLayout);
    }
    boolean delayed;
	
    public void playSound(Uri uri) {
        if (EnableSounds()) {
            if (!delayed) {
                delayed = true;
                if (FXPlayer != null) {
                    FXPlayer.stop();
                    FXPlayer.release();
                }
                FXPlayer = MediaPlayer.create(this, uri);
                if (FXPlayer != null)
					FXPlayer.setVolume(0.5f, 0.5f);
                FXPlayer.start();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            delayed = false;
                        }
                    }, 100);
            }
        }
    }
	
	
	
	public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
        this.expire = paramIntent.getStringExtra("EXPIRY");
        return START_NOT_STICKY; }

    public void onStartCommand(Intent paramIntent) {
        stopSelf();
        try {
            Thread.sleep(80L);
        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(paramIntent);
    }
	
	
	

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }
	
	
	
	
	
	private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }
	
	
	
	
	

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

	
	
	
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }
	
	
	
	

	private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

	
	
	
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

	
	
	
	public void Thread() {
        if (mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {

        } else {
            mFloatingView.setVisibility(View.VISIBLE);
        }
    }
	
	
	
	

    private interface InterfaceBtn {
        void OnWrite();
    }
	
	
	
	

    private interface InterfaceInt {
        void OnWrite(int i);
    }
	
	
	
	

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }
	
	
	
	

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}



