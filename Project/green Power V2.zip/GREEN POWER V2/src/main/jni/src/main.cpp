#include <pthread.h>
#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include <src/Substrate/SubstrateHook.h>
#include "src/Unity/Quaternion.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/Hook.h"
#include "src/Unity/Global.h"
#include "src/CANVAS/Bools.h"
#include "src/CANVAS/ESP.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"

# define getRealOffset(offset) AgetAbsoluteAddress("libil2cpp.so",offset)
# define HOOK(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

using namespace std;
ESP espOverlay;

extern "C" {
JNIEXPORT jboolean JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_EnableSounds(
        JNIEnv *env,
        jobject activityObject) {
    return true;
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Title(
        JNIEnv *env,
        jobject activityObject) {
        	
    jstring str = env->NewStringUTF("");
    return str;
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Heading(
        JNIEnv *env,
        jobject activityObject) {
        	
    return env->NewStringUTF("Free Fire 1.64.x");
}


JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Icon(
        JNIEnv *env,
        jobject activityObject) {
    return env->NewStringUTF(
                        "");
            }

JNIEXPORT jint JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_IconSize(
        JNIEnv *env,
        jobject activityObject) {
    return 60;
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Icon2(JNIEnv *env,jobject activityObject) {
    return env->NewStringUTF("");
    }
    
JNIEXPORT jint JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_IconSize2(
        JNIEnv *env,
        jobject activityObject) {
    return 35;
}

JNIEXPORT jstring JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Toast(
        JNIEnv *env,
        jclass clazz) {
    return env->NewStringUTF("");
}

JNIEXPORT jobjectArray JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
	
    "CT_MENU AIMBOT",//0
    "TG_AIM TIRO", //1
    "TG_AIM MIRO", //2
    "TG_ONE TAP HEAD", //3
    "SB78_AIM SPOT_0_2", //4
    "SB_AIM FOV_0_360", //5
    "CT_MENU ESP",//6
	"TG_ESP GRENDA",//7
    "SB_GRENDA COLER_0_6",//8
	"TG_ESP FIRE",//9
	
    };

int Total_Feature = (sizeof features /
sizeof features[0]); //Now you dont have to manually update the number everytime;
ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
env->NewStringUTF(""));
int i;
for (i = 0; i < Total_Feature; i++)
env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
return (ret);
}

struct My_Patches {


} KW;
	
bool KMHack1 = false,
KMHack2 = false,
KMHack3 = false,
KMHack4 = false,
KMHack5 = false,
KMHack6 = false,
KMHack7 = false,
KMHack8 = false,
KMHack9 = false,
KMHack10 = false,
KMHack11 = false,
KMHack12 = false,
KMHack13 = false,
KMHack14 = false,
KMHack15 = false,
KMHack16 = false;

struct {
	
bool teleKill = false;
bool aimAuto = false;
bool aimScope = false;
bool aimFire = false;
bool aimSquat = false;
bool aimLegit = false;
bool aimCaido = false;
bool FOV = true;
bool TeleportPlayer = false;
bool aimbotauto = true;
bool DriverSkill = false;
bool AlertAround = false; 
bool espNames = false;
bool ghost = false;
bool espFPS = false;
bool DesactiveFunctions = false;
bool espFire = false;
bool espfire2 = false;

bool Gravidade = false; 
bool verificacao = false;
	
bool aimCabeca = true;
bool aimPeito = false;
bool aimPe = false;

bool espGranade = false;
	
bool espCout = false;
bool AlvoEnemyPos = false;

int enemyCountAround = 0;
int botCountAround = 0;

Color GrandaColor = Color::White();
Color Changecolor = Color::White();
Color LineColor = Color::White();
Color TextColor = Color::White();
bool EspAlvoUnico = false;
Color Espcoloralvo = Color::DarkGolden();
	
float Fov_Aim = 0.0f;
float TextSize = 17.0f;
float Linesize = 1.5f;
float TFPosX = 0.0f;
float TFPosY = 0.0f;
float TFPosZ = 0.0f;

void *TFPos = nullptr;

int conttelekill = 1;
int velocidade = 0;
int semihs = 0;
int AimDistance = 0;
	
} HP;

std::string indetifiq;

bool verify = false;
bool active = true;
bool launched = false;

bool Chan999 = false;
bool AutoKill = false;
bool SkilCris = false;

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_Changes(JNIEnv *env, jobject activityObject, jint feature, jint value) {
    
    switch (feature) {
    
    case 0:
    break;
    
    case 1:
    HP.aimFire = !HP.aimFire;
    break;
            
    case 2:
    HP.aimScope = !HP.aimScope;
    break;
            
    case 3:
    HP.aimSquat = !HP.aimSquat;
    break;
			
    case 4:
	if (value == 0) {
    HP.aimPeito = !HP.aimPeito;
    HP.aimPeito = true;
    HP.aimCabeca = false;
    HP.aimPe = false;
    } else if (value == 1) {
    HP.aimCabeca = !HP.aimCabeca;
    HP.aimCabeca = true;
    HP.aimPeito = false;
    HP.aimPe = false;
    } else if (value == 2) {
    HP.aimPe = !HP.aimPe;
    HP.aimPe = true;
    HP.aimPeito = false;
    HP.aimCabeca = false;
    }
	break;
        
    case 5:
    HP.Fov_Aim = (float)value;
    if(value == 0) {
    HP.Fov_Aim = 0.0f;
	}
    break;
    
    case 6:
    break;
		
	case 7:
	HP.espGranade = !HP.espGranade;
	break;
			
    case 8:
    if (value == 0) {
	HP.GrandaColor = Color::Red();
	} else if (value == 1) {
	HP.GrandaColor = Color::Green();
	} else if (value == 2) {
	HP.GrandaColor = Color::Blue();
	} else if (value == 3) {
	HP.GrandaColor = Color::White();
	} else if (value == 4) {
	HP.GrandaColor = Color::Yellow();
	} else if (value == 5) {
	HP.GrandaColor = Color::Cyan();
	} else if (value == 6) {
    HP.GrandaColor = Color::Magenta();
    }
    break;
		
	case 9:
    HP.espFire = !HP.espFire;
	HP.espfire2 = !HP.espfire2;
    break;
    
    }
}
}
Color EspColor = Color::Green();
Vector3 GetHeadPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HeadTF));
}

Vector3 GetHipPosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HipTF));
}

Vector3 GetToePosition(void* player) {
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.ToeTF));
}

Vector3 CameraMain(void* player){
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.MainCameraTransform));
}

void *GetClosestEnemy(void *match) {
    if(!match) {
        return NULL;
    }
	
    float shortestDistance = 99999.0f;
    float maxAngle = HP.Fov_Aim;
    void* closestEnemy = NULL;
    void* LocalPlayer = GetLocalPlayer(match);
    if(LocalPlayer != NULL && !get_IsDieing(LocalPlayer)) {
		monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + Global.Dictionary);
		for(int u = 0; u < players->getNumValues(); u++) {
            void* Player = players->getValues()[u];
			if(Player != NULL && !get_isLocalTeam(Player) && !get_IsDieing(Player) && get_isVisible(Player) && get_MaxHP(Player)) {
                Vector3 PlayerPos = GetHipPosition(Player);
                Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
                if(HP.FOV) {
                    Vector3 targetDir = Vector3::Normalized(PlayerPos - LocalPlayerPos);
                    float angle = Vector3::Angle(targetDir, GetForward(Component_GetTransform(Camera_main()))) * 100.0;
					if(angle <= maxAngle) {
                        if(angle < shortestDistance) {
                            shortestDistance = angle;
                            closestEnemy = Player;
                        }
                    }
                } else {
                    if(maxAngle < shortestDistance) {
                        shortestDistance = maxAngle;
                        closestEnemy = Player;
                    }
                }
            }
        }
    }
    
	return closestEnemy;
}

void (*Update)(void* gamestartup);
void _Update(void* gamestartup) {

    if(Update) {
		if (HP.DesactiveFunctions) {}
        void* Match = Curent_Match();
        if((HP.aimAuto || HP.aimScope || HP.aimSquat || HP.aimFire) && Match) {
            void* LocalPlayer = GetLocalPlayer(Match);
            if(LocalPlayer) {
			void* closestEnemy = GetClosestEnemy(Match);
				if(closestEnemy) {
					
                    Vector3 EnemyHeadLocation = GetHeadPosition(closestEnemy);
					Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
					Vector3 PlayerLocation = CameraMain(LocalPlayer);
					Vector3 CenterWS = GetAttackableCenterWS(LocalPlayer);
					
					Quaternion PlayerLook = GetRotationToLocation(GetHeadPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook2 = GetRotationToLocation(GetHipPosition(closestEnemy), 0.1f, PlayerLocation);
					Quaternion PlayerLook3 = GetRotationToLocation(GetToePosition(closestEnemy), 0.1f, PlayerLocation);
					
					float distance = Vector3::Distance(CenterWS, EnemyLocation);
					
					Vector3 LocalPlayerPos = GetHeadPosition(LocalPlayer);
					Vector3 PlayerPos = GetHeadPosition(closestEnemy);
					
					Vector3 HeadTF = GetHeadPosition(closestEnemy);
					void* CurrentWP = get_imo(LocalPlayer);
					
					bool scope = get_IsSighting(LocalPlayer);
					bool agachado = get_IsCrouching(LocalPlayer);
					bool firing = get_IsFiring(LocalPlayer);
					bool caido = get_IsDieing(closestEnemy);

if (HP.DriverSkill) {
set_aim(LocalPlayer, PlayerLook);
void* LocalCar = VehicleIAmIn(LocalPlayer);
if (LocalCar) {
Set_Position(Component_GetTransform(LocalCar), Vvector3(EnemyLocation.X, EnemyLocation.Y + 0.6f, EnemyLocation.Z));
}
}

/*if (HP.espFire) {
void *imo = get_imo(LocalPlayer);
if (imo != NULL && distance > 1.0f) {
set_esp(imo, CenterWS, EnemyLocation);
}
}

if(HP.espfire2) {
Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main()));
Vector3 BodyZPos = GetHeadPosition(LocalPlayer);
Vector3 From2 = From + Vector3(0, 1,(BodyZPos.Z - From.Z));
Vector3 To = GetHeadPosition(closestEnemy);
set_esp(CurrentWP,From2,To);
}

if (HP.espFire) {
void *imo = get_imo(LocalPlayer);
if (imo != NULL) {
set_esp(imo, CenterWS, HeadTF);
}
}
*/
if(HP.espFire) {
if (HP.espFire) {
void *imo = get_imo(LocalPlayer);
if (imo != NULL) {
set_esp(imo, CenterWS, EnemyLocation);
}
}
            
if(HP.espfire2) {
void* CenterWS = get_imo(LocalPlayer);
Vector3 From = Transform_INTERNAL_GetPosition(Component_GetTransform(Camera_main())) + Vector3(2,4,2);
Vector3 To = GetHeadPosition(closestEnemy);
set_esp(CenterWS,From,To);
}
}


if(HP.espGranade) {
GrenadeLine_DrawLine(Grenade2, LocalPlayerPos, LocalPlayerPos, Vector3(0,1,0) * 0.9);
((void (*)(void *, Color))getRealOffset(0x37BD870))(Render2, HP.GrandaColor);
((void (*)(void *, Color))getRealOffset(0x37BD894))(Render2, HP.GrandaColor);
if (Render2) {
LineRenderer_Set_PositionCount(Render2, 0x2); 
LineRenderer_SetPosition(Render2, 0, LocalPlayerPos);
LineRenderer_SetPosition(Render2, 1, PlayerPos);
}
}

if(HP.TeleportPlayer) {
set_aim(LocalPlayer, PlayerLook);
void *_MountTF = Component_GetTransform(closestEnemy);
if (_MountTF != NULL) {
Vector3 MountTF =
Transform_INTERNAL_GetPosition(_MountTF) - (GetForward(_MountTF) *  0.6f);
Transform_INTERNAL_SetPosition(Component_GetTransform(LocalPlayer), Vvector3(MountTF.X, MountTF.Y, MountTF.Z));
}
}

					if (HP.aimAuto) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
               
					if (scope && HP.aimScope) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
					
					if (agachado && HP.aimSquat) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
						
					if (firing && HP.aimFire) {
						if(HP.aimCabeca) {
							set_aim(LocalPlayer, PlayerLook);
						}
							
						if(HP.aimPeito) {
							set_aim(LocalPlayer, PlayerLook2);
						}
							
						if(HP.aimPe) {
							set_aim(LocalPlayer, PlayerLook3);
						}
					}
					
					if (firing && HP.aimLegit) {
						if (HP.aimbotauto)
						{
							set_aim(LocalPlayer, PlayerLook2);
							++HP.semihs;
						} else {
							set_aim(LocalPlayer, PlayerLook);
							--HP.semihs;
						}
               
						if (HP.semihs == 6)
						{
							HP.aimbotauto = false;
						} else if (HP.semihs == 0) {
							HP.aimbotauto = true;
						}
               
						if (HP.semihs > 6 || HP.semihs < 0)
						{
							HP.semihs = 3;
							HP.aimbotauto = true;
						}
					}
                }
            }
        }
    }
	Update(gamestartup);
}

void (*LateUpdate)(void *componentPlayer);

void *playerlate = NULL;
void *get_Player(void *player){
    playerlate = player;
    return playerlate;
}

void *fakeEnemy;
void _LateUpdate(void *player){
    if (player != NULL) {
		if (HP.DesactiveFunctions) {}
        void *local_player = Current_Local_Player();
        if (local_player == NULL){
            local_player = GetLocalPlayerOrObServer();
        }
        if (local_player != NULL){
            void *current_match = Curent_Match();
            if (current_match != NULL) {
            if (HP.AlertAround) {
                ShowDynamicPopupMessage(FormatCount(HP.enemyCountAround, HP.botCountAround));
                }
                int tmpEnemyCountAround = 0;
                int tmpBotCountAround = 0;
                monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t *, void **> **) ((long) current_match + 0x44);
                for (int u = 0; u < players->getNumValues(); u++) {
                    void *closestEnemy = players->getValues()[u];
                    HP.enemyCountAround = tmpEnemyCountAround;
                    HP.botCountAround = tmpBotCountAround;
                    if(closestEnemy != NULL && closestEnemy != player && !get_isLocalTeam(closestEnemy) && get_isVisible(closestEnemy) && get_MaxHP(closestEnemy)) {
                        if (closestEnemy != NULL) {
                            bool isBot = *(bool*)((uintptr_t)closestEnemy + Global.IsClientBot);
                            if (isBot) {
                                ++tmpBotCountAround;
                            } else {
                                ++tmpEnemyCountAround;
                            }
                        }
                        
                        if(closestEnemy != local_player) {
                            Vector3 EnemyLocation = GetHeadPosition(closestEnemy);
                            Vector3 CenterWS = GetAttackableCenterWS(local_player);
                         
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
             
                if (fakeCamPlayer != NULL && fakeCamEnemy != NULL){
                    void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
                
                    if (fakeCamPlayerTF != NULL && fakeCamEnemyTF != NULL) {
                        Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
                     
                        if (player != local_player) {
                          
                            if (distance < 1.6f) {
                                fakeEnemy = player;
                            }
                        }

                    }
                }
	        }
        }
    }
	}
	}
	}
	
    get_Player(player);
    LateUpdate(player);
}

static bool isEspReady() {
	return false;
}

void DrawESP(ESP esp, int screenWidth, int screenHeight) {
    void *player = playerlate;
    
		if (player != NULL) {
			if (HP.DesactiveFunctions) {
        void *current_match = Curent_Match();    
		if (current_match != NULL) {
            void *local_player = Current_Local_Player();          
			if (local_player == NULL) {
                local_player = GetLocalPlayerOrObServer();
            }     
			if (local_player != NULL) {
                void *fakeCamPlayer = get_MyFollowCamera(local_player);
                void *fakeCamEnemy = get_MyFollowCamera(player);
				if (fakeCamPlayer != NULL && fakeCamEnemy != NULL) {         
					if (!isEspReady()) {    
						monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)current_match + Global.Dictionary);
                        void *camera = Camera_main();
						if (players != NULL && camera != NULL && players->getNumValues() >= 1) {         
							for(int u = 0; u < players->getNumValues(); u++) {
                                void* closestEnemy = players->getValues()[u];                   
								if (closestEnemy != NULL && closestEnemy != fakeEnemy) {        
									bool alive = get_isAlive(closestEnemy);                               
									bool visible = get_isVisible(closestEnemy);                           
									bool sameteam = get_isLocalTeam(closestEnemy);                                 
									if (closestEnemy != local_player && alive && visible && !sameteam) {                              
										void *HeadTF = *(void **) ((uintptr_t) closestEnemy + Global.HeadTF);
										void *HipTF = *(void **) ((uintptr_t) closestEnemy + Global.HipTF);
										void *Dedo = *(void **) ((uintptr_t) closestEnemy + Global.DedoTF);
										void *PeD = *(void **) ((uintptr_t) closestEnemy + Global.PeD);
										void *PeS = *(void **) ((uintptr_t) closestEnemy + Global.PeS);
										void *RShoulder = *(void **) ((uintptr_t) closestEnemy + Global.RShoulder);
										void *LShoulder = *(void **) ((uintptr_t) closestEnemy + Global.LShoulder);
										void *Hand = *(void **) ((uintptr_t) closestEnemy + Global.HandTF);
										void *Toe = *(void **) ((uintptr_t) closestEnemy + Global.ToeTF);			
										if (HeadTF != NULL && HipTF != NULL && Dedo != NULL && PeD != NULL && PeS != NULL && RShoulder != NULL && LShoulder != NULL && Hand != NULL && Toe != NULL) {								
											Vector3 Head = Transform_INTERNAL_GetPosition(HeadTF);
											Vector3 Hip = Transform_INTERNAL_GetPosition(HipTF);
											Vector3 DedoTF = Transform_INTERNAL_GetPosition(Dedo);
											Vector3 Ped = Transform_INTERNAL_GetPosition(PeD);
											Vector3 Pes = Transform_INTERNAL_GetPosition(PeS);
											Vector3 RShoulderr = Transform_INTERNAL_GetPosition(RShoulder);
											Vector3 LShoulderr = Transform_INTERNAL_GetPosition(LShoulder);
											Vector3 HandTF = Transform_INTERNAL_GetPosition(Hand);
											Vector3 ToeTF = Transform_INTERNAL_GetPosition(Toe);		
											
											Vector3 PositionHead = WorldToScreenPoint(camera, Head);
											if(PositionHead.Z < -1) continue;				
											
											Vector3 PositionHip = WorldToScreenPoint(camera, Hip);
											if(PositionHip.Z < -1) continue;			
											
											Vector3 PositionDedoS = WorldToScreenPoint(camera, DedoTF);
											if(PositionDedoS.Z < -1) continue;
											
											Vector3 PositionPeD = WorldToScreenPoint(camera, Ped);
											if(PositionPeD.Z < -1) continue;		
											
											Vector3 PositionPeS = WorldToScreenPoint(camera, Pes);
											if(PositionPeS.Z < -1) continue;		
											
											Vector3 PositionRShoulder = WorldToScreenPoint(camera, RShoulderr);
											if(PositionRShoulder.Z < -1) continue;
											
											Vector3 PositionLShoulder = WorldToScreenPoint(camera, LShoulderr);
											if(PositionLShoulder.Z < -1) continue;		
											
						     				Vector3 PositionHand = WorldToScreenPoint(camera, HandTF);
											if(PositionHand.Z < -1) continue;
											
											Vector3 PositionToe = WorldToScreenPoint(camera, ToeTF);
											if(PositionToe.Z < -1) continue;		
											
											Vector3 CenterWS = GetAttackableCenterWS(local_player);				
											
											float distance = Vector3::Distance(CenterWS, Head);			
											
											Vector3 End = PositionHead;
											Vector3 End2 = PositionToe;
											
											float boxWidth = static_cast<float>( ((screenWidth - PositionRShoulder.X * 0.995) - (screenWidth - PositionLShoulder.X * 1.005)) * 1.5);
											float Tamanho = 0.0f;
											float tamanhovida2 = (1080 / distance) + 18;
													
											if (distance > 10.0f) {
												Tamanho = 10.0f;
											} else if (distance < 20.0f) {
												Tamanho = 0.0f;
											}						
											float boxHeight = ((screenHeight - End2.Y) - (screenHeight - End.Y));
											Rect PlayerRect(End2.X - (boxWidth / 2), (screenHeight - End.Y), boxWidth, boxHeight + Tamanho);									
				
											
											}
										}
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

bool (*orig_ghost)(void* _this);
bool _ghost(void* _this){
    if (_this != NULL){
          if (HP.ghost || HP.teleKill){
            return false;
        }
    }
  return orig_ghost(_this);
}
///////
void(*NepmodsAntiCrash)(void* _this);
void _NepmodsAntiCrash(void* _this) {
    if (NepmodsAntiCrash != NULL) {
        return;
    }
    return NepmodsAntiCrash(_this);
}
//

///////
void *hack_thread(void *) {
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());

HOOK(0xC2A5C8, _Update, Update);//ok
HOOK(0xC25F18,_LateUpdate,LateUpdate);//ok
HOOK(0x17475D4, _ghost, orig_ghost);//ok

MemoryPatch("libil2cpp.so", 0x275BA8C + 136, "00 00 00 00", 4).Modify();
MemoryPatch("libil2cpp.so", 0x22af164 + 116, "00 00 00 00", 4).Modify();

HOOK(0x39883EC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x2EA5AB4, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x22AF068, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0xFEE058, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A80720, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8CE50, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A881BC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8A950, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8AD8C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0xFE47F0, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8B16C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A89D7C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8C648, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A90EF4, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A9109C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x12EDD70, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91468, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A915B4, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A917CC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A918B8, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91A04, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91B44, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91C84, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91DC4, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A91EC0, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A924EC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A92290, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A925D8, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A92848, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A92ECC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A930E0, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A933E4, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A93648, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A937AC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8C870, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8CB5C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8CF78, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8D3DC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8DF10, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8E01C, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8E7C8, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x1A8EBFC, _NepmodsAntiCrash, NepmodsAntiCrash); //[1.80]
HOOK(0x74BA28, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x74F1C8, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x153FCE4, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x7662DC, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x22DB184, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x1CE2F90, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x1CE2FE8, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x1CE328C, _NepmodsAntiCrash, NepmodsAntiCrash);
HOOK(0x76771C, _NepmodsAntiCrash, NepmodsAntiCrash);

HOOK(0x20DC02C, GrenadeLine_Update, _GrenadeLine_Update);
MSHookFunction((void *)getRealOffset(Global.GrenadeLine_Update), (void *)GrenadeLine_Update, (void **)&_GrenadeLine_Update);

	return NULL;
}

extern "C" 
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    espOverlay = ESP(env, espView, canvas);
    
    if (espOverlay.isValid()){
        DrawESP(espOverlay, espOverlay.getWidth(), espOverlay.getHeight());
    }
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
    return JNI_VERSION_1_6;
}

