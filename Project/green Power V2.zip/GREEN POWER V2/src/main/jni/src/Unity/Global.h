#ifndef ANDROID_MOD_MENU_GLOBAL_H
#define ANDROID_MOD_MENU_GLOBAL_H

struct {

    uintptr_t HeadTF = 0x220;//protected Transform JIMLGADEEEB;
    uintptr_t HipTF = 0x224;//protected Transform ECBHDOHKAJK;
    uintptr_t ToeTF = 0x238;//protected Transform CJPKLAMIPDH;
    uintptr_t RShoulder = 0x254;//protected Transform GOCJFBEHCAC;
    uintptr_t LShoulder = 0x258;//protected Transform IIALIDGNNBN;
    uintptr_t PeS = 0x244;//protected Transform MKNLMLBEOAB;
    uintptr_t PeD = 0x248;//protected Transform JKNBJGFGGEE;
    uintptr_t DedoTF = 0x24C;//protected Transform GPDGJGNEBMP;
	uintptr_t HandTF = 0x21C;//protected Transform GDFHKNFHCEO;

    uintptr_t MainCameraTransform = 0x88;//public Transform MainCameraTransform;
    uintptr_t Dictionary = 0x48;//private Dictionary<ParticleSystem, ParticleSystem.MinMaxCurve> m_CGLoopParticleSystemDelayTable;
    uintptr_t IsClientBot = 0x110;//public bool IsClientBot;
    
    uintptr_t U3DStr = 0x398523C;//ok
    uintptr_t Component_GetTransform = 0x399D0CC;//ok
    uintptr_t Transform_INTERNAL_GetPosition = 0x47AF9C8;//ok
    uintptr_t Transform_INTERNAL_SetPosition = 0x47AFA68;//ok
    uintptr_t GetForward = 0x47B0528;//ok
    uintptr_t GetLocalPlayer = 0x20218E8;//ok
    uintptr_t GetLocalPlayerOrObServer = 0x10D41BC;//ok
    uintptr_t Camera_main = 0x399B2A4;//ok
	
    uintptr_t get_isAlive = 0xC54194;//ok
    uintptr_t get_isVisible = 0xBF3058;//ok
    uintptr_t get_IsDieing = 0xBEE328;//ok
    uintptr_t get_IsSighting = 0xC86350;//ok
    uintptr_t get_IsCrouching = 0xBFDDF4;//ok
    uintptr_t get_isLocalTeam = 0xBFBB88;//ok
    
    uintptr_t get_imo = 0xBF6478;//ok
    uintptr_t get_main = 0x399B2A4;//ok
    uintptr_t get_IsFiring = 0xC48FE4;//ok
    uintptr_t get_CurHp = 0x1E945C8;//ok
    uintptr_t get_MaxHP = 0x1E94818;//ok
    uintptr_t get_NickName = 0xBEC668;//ok
    uintptr_t get_MyFollowCamera = 0xBEE4D8;//ok
	
    uintptr_t set_aim = 0xBEF8CC;//ok
	uintptr_t set_esp = 0xF156A4;//ok
    
    uintptr_t Curent_Match = 0x10D21DC;//ok
    uintptr_t CurrentUIScene = 0x10D1238;//ok
    uintptr_t Current_Local_Player = 0x10D25CC;//ok
    uintptr_t ShowDynamicPopupMessage = 0xCD6854;//ok
    uintptr_t ShowPopupMessage = 0xCAC9DC;
    uintptr_t ShowAssistantText = 0xCF2C18;//ok
    uintptr_t CurrentMatch = 0x10D21DC;//ok
    uintptr_t WorldToScreenPoint = 0x399A930;//ok
	uintptr_t GetAttackableCenterWS = 0x1E6F5C4;//ok
	uintptr_t GetLocalCar = 0xBF0AA4;//ok
    
	uintptr_t LineRenderer_Set_PositionCount = 0x37bd8bc;//public void set_positionCount(int value) { } 1.80
    uintptr_t LineRenderer_SetPosition = 0x37be3f0;//public void SetPosition(int index, Vector3 position) { } 1.80
    uintptr_t GrenadeLine_DrawLine = 0x20dcd34;//private void DrawLine2(Vector3 throwPos, Vector3 throwVel, Vector3 gravity) { } 1.80
    uintptr_t GrenadeLine_Update = 0x20dc518;//private void Update() { } 1.80
    uintptr_t set_startColor = 0x37BD870;//ok
    uintptr_t set_endColor = 0x37BD894;//ok
    
} Global;

#endif


