package uk.lgl.modmenu;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.graphics.drawable.Drawable;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;
import uk.lgl.modmenu.ESPView;


import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import android.graphics.drawable.Drawable;
import java.io.File;
import java.io.IOException;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Random;


import java.io.InputStream;
import android.graphics.drawable.GradientDrawable;

public class FloatingModMenuService extends Service {
    private MediaPlayer FXPlayer;
    public View mFloatingView;
    private ImageView ffid,CLOSEBAD,MINIMIZE;
	private TextView username;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
	private ImageView closeimage;
    private LinearLayout view1;
    private LinearLayout view2;
	Button settings ;
	
	
    private static final String TAG = "Mod Menu";
	private interface C0518BT {
        void onClick();
    }
	
	public float dipToPixels() {
        return TypedValue.applyDimension(1, 8.0f, getResources().getDisplayMetrics());
    }
	
	//Canvas 
	private ESPView overlayView;
	public static native void DrawOn(ESPView espView, Canvas canvas);
	private WindowManager.LayoutParams espParams;
	

    private LinearLayout.LayoutParams hr;
	
	public native void changeToggle(int i);
	
    public static native String Toast();
	
    private native String Title();
	
    private native String Icon();
	
    private native String Icon2();
	
    private native boolean EnableSounds();
	
    private native int IconSize();
	
    public native void Changes(int feature, int value);
	
    private native String[] getFeatureList();
	
	private String expire;
	private String Credits(){
        return "Dias Restantes: " +expire;
    }
	
	
	private String Heading(){
        return "";
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
	
	private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return 2002;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return 2003;
    }

	private void DrawCanvas() {
        WindowManager.LayoutParams layoutParams;
        this.espParams = layoutParams = new WindowManager.LayoutParams(-1, -1, this.getLayoutType(), 56, -3);
        layoutParams.gravity = 8388659;
        this.espParams.x = 0;
        this.espParams.y = 0;
        this.mWindowManager.addView((View)this.overlayView, (ViewGroup.LayoutParams)this.espParams);
    }
	
	
	public void onCreate() {
        super.onCreate();
        System.loadLibrary("FFH4X");
		this.overlayView = new ESPView((Context)this);
        initFloating();
		DrawCanvas();
        final Handler handler = new Handler();
        handler.post(new Runnable() {
                public void run() {
                    Thread();
                    handler.postDelayed(this, 1000);
                }
            });
    }

    public WindowManager.LayoutParams setParams() {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(-1, -1);
        params.gravity = 16;
        params.flags = 8192;
        return params;
    }
	

	private void addCategory(String text) {
        Button textView = new Button(this);
        textView.setText(text);
        textView.setGravity(17);
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.BLACK);
        textView.setPadding(10, 5, 10, 5);
        //patches.addView(textView);
    }


	private void addCategory2(String text) {
        TextView textView = new TextView(this);
		textView.setText(text);
        textView.setTextSize(dipToPixels());
		textView.setTextSize(15.0f);
		textView.setTextColor(Color.RED);
		textView.setLayoutParams(setParams());
       // patches.addView(textView);
    }

	


	private void addSwitch(String str, final InterfaceBool sw) {

		final GradientDrawable g= new  GradientDrawable();
        g.setSize(59,45);
        g.setShape(0);
        g.setStroke(3,Color.parseColor("#FFFFFF"));
        g.setColor(Color.parseColor("#000000"));
		g.setCornerRadius(5);
        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.LTGRAY);
        gd.setSize(3,4);
        gd.setStroke(3,Color.parseColor("#00000000"));
        gd.setCornerRadius(9);

        final Switch switchR = new Switch(this);
        switchR.setText(Html.fromHtml("<font face=><b>" + str + "</b></font>"));
        switchR.setTextColor(Color.parseColor("#FFFFFFFF"));
        switchR.setPadding(10, 5, 0, 5);
		switchR.setThumbDrawable(g);
        switchR.setTrackDrawable(gd);

		
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        
						gd.setColor(Color.parseColor("#00ff00"));
						

                    } else {
						gd.setColor(Color.LTGRAY);
						// switchR.getTrackDrawable().setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_IN);
						//  switchR.getThumbDrawable().setColorFilter(Color.parseColor("WHITE"), PorterDuff.Mode.SRC_IN);
                    }
                    sw.OnWrite(z);
                }
            });

        this.patches.addView(switchR);
    }

	private void addSeekBar(String str,  int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(18);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setBackgroundColor(Color.parseColor("#00000000"));
        TextView textView = new TextView(this);
        textView.setText(Html.fromHtml("<font face=><b>" + str + ": <font color='WHITE'>" + "0" + "</font>"));
		textView.setTextSize(14);
        textView.setTextColor(Color.WHITE);
        SeekBar seekBar = new SeekBar(this);
        GradientDrawable seekbar = new GradientDrawable();
        seekbar.setShape(0);
        seekbar.setColor(Color.parseColor("#000000"));
        seekbar.setStroke(dp(1), Color.parseColor("#ffffff"));
        seekbar.setCornerRadius(3.0f);
        seekbar.setSize(dp(15), dp(15));
		
        seekBar.setThumb(seekbar);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        seekBar.setMax(max);
        seekBar.setProgress(progress);

        if (Build.VERSION.SDK_INT >= 21) {
			seekBar.getProgressDrawable().setTint(Color.parseColor("#00ff00"));
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
		final String str3 = str;
		seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                private String itv;
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					int i2 = i5;
					if (i < i2) {
                        seekBar2.setProgress(i2);
                        sb3.OnWrite(i5);
                        TextView textView = textView2;
						textView.setText(Html.fromHtml("<font face=><b>" + str3 + ": <font color='#FF0000'>" + "0" + "</font>"));
						
						return;
                    }
                    sb3.OnWrite(i);
					textView2.setText(Html.fromHtml("<font face=><b>" + str3 + ": <font color=WHITE'>" +  i + "</b></font>"));
					
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
		patches.addView(linearLayout);
    }
	
	
	

    //Here we write the code for our Menu
    private void initFloating() {
        this.rootFrame = new FrameLayout(this);
        this.mRootContainer = new RelativeLayout(this);
        this.mCollapsed = new RelativeLayout(this);
        this.mExpanded = new LinearLayout(this);
        this.view1 = new LinearLayout(this);
		Context paramContext = getBaseContext();
		float scale = getBaseContext().getResources().getDisplayMetrics().density;
        this.patches = new LinearLayout(this);
        this.view2 = new LinearLayout(this);
		AssetManager assetManager = getAssets();
        this.mButtonPanel = new LinearLayout(this);


        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) IconSize(), getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close2 = null;
        try {
            inputStream_close2 = assetManager.open("icon.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close2 = Drawable.createFromStream(inputStream_close2, null);
        startimage.setImageDrawable(ic_close2);
        startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
		
		//RelativeLayout.LayoutParams layoutExpanded_LayoutParams = new RelativeLayout.LayoutParams(-2, -2);
        this.mExpanded.setVisibility(8);
        this.mExpanded.setBackgroundColor(Color.parseColor("#ff000000"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(1);
		this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(300), -2));
        this.mExpanded.setPadding(5, 5, 5, 0);
     
        android.graphics.drawable.GradientDrawable DFIABBI = new android.graphics.drawable.GradientDrawable();
        DFIABBI.setColor(Color.parseColor("#C8000000"));
        DFIABBI.setCornerRadius(10);
        DFIABBI.setStroke(5, 0);
        this.mExpanded.setBackground(DFIABBI);
		

		ScrollView scrollView = new ScrollView(this);
		LinearLayout.LayoutParams scrollView_LayoutParams = new LinearLayout.LayoutParams(-2, -2);
        scrollView_LayoutParams.height = (int) ((261.0f * scale) + 0.5f);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(190)));
        scrollView.setBackgroundColor(Color.BLACK);
    
		android.graphics.drawable.GradientDrawable DFIABBI2 = new android.graphics.drawable.GradientDrawable();
        DFIABBI2.setColor(0);
        DFIABBI2.setCornerRadius(10);
        DFIABBI2.setStroke(5, 0);
        scrollView.setBackground(DFIABBI2);
//	scrollView.setPadding(5,5,5,5);
		
		
        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(1);
		
        this.hr = new LinearLayout.LayoutParams(-1, -1);
        this.hr.setMargins(0, 0, 0, 5);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));


		//BUTTON CLOSE
		RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(10, 10, 10, 10);
        relativeLayout.setVerticalGravity(16);
		RelativeLayout.LayoutParams layoutParamsAf = new RelativeLayout.LayoutParams(dp(60), dp(27));
        layoutParamsAf.addRule(11);
		RelativeLayout.LayoutParams layoutParamskA = new RelativeLayout.LayoutParams(dp(60), dp(27));
        layoutParamskA.addRule(11);
		
		Button BAD_MODDER = new Button(this);
        BAD_MODDER.setPadding(0, 5, 0, 5);
        BAD_MODDER.setBackgroundColor(Color.rgb(0,116,186));
        BAD_MODDER.setText("CLOSE");  
		BAD_MODDER.setTextColor(-1);
		BAD_MODDER.setTypeface(null,Typeface.NORMAL);    
        BAD_MODDER.setTextSize(15.0f);
        BAD_MODDER.setGravity(17);
        android.graphics.drawable.GradientDrawable
		DFIABBIf = new android.graphics.drawable.GradientDrawable();
        DFIABBIf.setColor(0);
        DFIABBIf.setCornerRadius(10);
        DFIABBIf.setStroke(2, -1);
        BAD_MODDER.setBackground(DFIABBIf);
        BAD_MODDER.setLayoutParams(layoutParamsAf);
		
		Button BAD_MODDER2 = new Button(this);
        BAD_MODDER2.setPadding(0, 5, 0, 5);
		/*BAD_MODDER2.setLayoutParams(layoutParams);
		layoutParams.bottomMargin = dp(2);
		layoutParams.rightMargin =  dp(2);*/
        BAD_MODDER2.setBackgroundColor(Color.rgb(0,116,186));
        BAD_MODDER2.setText("CLOSE");  
		BAD_MODDER2.setTextColor(-1);
		BAD_MODDER2.setTypeface(null,Typeface.NORMAL);    
        BAD_MODDER2.setTextSize(15.0f);
        BAD_MODDER2.setGravity(17);
        android.graphics.drawable.GradientDrawable
		DFIABBIf23 = new android.graphics.drawable.GradientDrawable();
        DFIABBIf23.setColor(0);
        DFIABBIf23.setCornerRadius(10);
        DFIABBIf23.setStroke(2, -1);
        BAD_MODDER2.setBackground(DFIABBIf23);
        BAD_MODDER2.setLayoutParams(layoutParamskA);
		
        this.ffid = new ImageView(this);
		RelativeLayout.LayoutParams ffid_LayoutParams = new RelativeLayout.LayoutParams(-5, -3);
        this.ffid.setLayoutParams(new RelativeLayout.LayoutParams(-5, -3));
		ffid_LayoutParams.width = (int) ((50.0f * scale) + 0.5f);
        ffid_LayoutParams.height = (int) ((50.0f * scale) + 0.5f);
        ffid_LayoutParams.addRule(21, -1);
        ffid_LayoutParams.setMarginEnd((int) ((200.0f * scale) + 0.7f));
        this.ffid.getLayoutParams().height = dp(35);
        this.ffid.getLayoutParams().width = dp(75);
        this.ffid.requestLayout();
        this.ffid.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close3 = null;
        try {
            inputStream_close3 = assetManager.open("Aryan_Xd.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close3 = Drawable.createFromStream(inputStream_close3, null);
        ffid.setImageDrawable(ic_close3);
        ((ViewGroup.MarginLayoutParams) this.ffid.getLayoutParams()).leftMargin = convertDipToPixels(5);
		
		
		//Image Close Exit
		closeimage = new ImageView(getBaseContext());
        closeimage.setLayoutParams(new RelativeLayout.LayoutParams(-3, -8));
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(5);
        int dimensionClose = 23;
        int dimensionInDpClose = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dimensionClose, getResources().getDisplayMetrics());
        closeimage.getLayoutParams().height = dimensionInDpClose;
        closeimage.getLayoutParams().width = dimensionInDpClose;
        closeimage.requestLayout();
        InputStream inputStream_close = null;
        try {
            inputStream_close = assetManager.open("Aryan_JHA.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close = Drawable.createFromStream(inputStream_close, null);
        closeimage.setImageDrawable(ic_close);
        closeimage.setAlpha(220);
        ((ViewGroup.MarginLayoutParams) closeimage.getLayoutParams()).leftMargin = (40);
        ((ViewGroup.MarginLayoutParams) closeimage.getLayoutParams()).leftMargin = convertDipToPixels(55);
		
		
		

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);
	
		this.username = new TextView(this);
        RelativeLayout.LayoutParams username_LayoutParams = new RelativeLayout.LayoutParams(-9, -9);
        username_LayoutParams.width = (int) ((300.0f * scale) + 0.10f);
        Context context = paramContext;
        username_LayoutParams.addRule(20, -1);
        username_LayoutParams.topMargin = (int) ((300.0f * scale) + 0.10f);
        username_LayoutParams.setMarginEnd((int) ((300.0f * scale) + 0.10f));
        this.username.setAllCaps(true);
        this.username.setTextColor(Color.parseColor("#000000"));
        this.username.setLayoutParams(username_LayoutParams);
		this.username.setText("ARYAN JHA\nARYAN JHA");
        this.username.setGravity(30);
		username.setLayoutParams(new LinearLayout.LayoutParams(dp(100), dp(150)));
		this.username.setPadding(0, 0, 0, 10);
		this.username.setLayoutParams(layoutParams);
		
       // relativeLayout.addView(this.ffid);
		//relativeLayout.addView(this.username);

		
		RelativeLayout titleText = new RelativeLayout(this);
        titleText.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        titleText.setPadding(0, 0, 0, 0);
        titleText.setVerticalGravity(16);
        this.CLOSEBAD = new ImageView(this);
        RelativeLayout.LayoutParams CLOSEBAD_LayoutParams = new RelativeLayout.LayoutParams(-5, -3);
        this.CLOSEBAD.setLayoutParams(new RelativeLayout.LayoutParams(-5, -3));
        CLOSEBAD_LayoutParams.width = (int) ((50.0f * scale) + 0.5f);
        CLOSEBAD_LayoutParams.height = (int) ((50.0f * scale) + 0.5f);
        CLOSEBAD_LayoutParams.addRule(21, -1);
        CLOSEBAD_LayoutParams.setMarginEnd((int) ((200.0f * scale) + 0.7f));
        this.CLOSEBAD.getLayoutParams().height = dp(30);
        this.CLOSEBAD.getLayoutParams().width = dp(30);
        this.CLOSEBAD.requestLayout();
        this.CLOSEBAD.setScaleType(ImageView.ScaleType.FIT_XY);
        InputStream inputStream_close33 = null;
        try {
            inputStream_close33 = assetManager.open("ARYAN_JHA/close.png");
        } catch (IOException e) {
            e.printStackTrace();
        }
        Drawable ic_close33 = Drawable.createFromStream(inputStream_close33, null);
        CLOSEBAD.setImageDrawable(ic_close33);
        ((ViewGroup.MarginLayoutParams)
        this.CLOSEBAD.getLayoutParams()).leftMargin = convertDipToPixels(5);
        RelativeLayout.LayoutParams rlz = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlz.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        CLOSEBAD.setLayoutParams(rlz);
        
        RelativeLayout.LayoutParams layoutParamsA = new RelativeLayout.LayoutParams(dp(60), dp(27));
        layoutParamsA.addRule(11);
        

        TextView textView2 = new TextView(this);
        textView2.setText(Html.fromHtml("<font color='Green'>Green</font>"+"Power Injetor"));
        
        textView2.setTextColor(Color.WHITE);
        textView2.setTextSize(22.54f);
        Typeface typefaceR = Typeface.createFromAsset(getAssets(), "Badmodd/mod.ttf"); 
		textView2.setTypeface(typefaceR);
       
        RelativeLayout.LayoutParams rl = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rl.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        textView2.setLayoutParams(rl);

        settings = new Button(this);
        settings.setPadding(0, 5, 0, 5);
		settings.setLayoutParams(layoutParams);
		layoutParams.bottomMargin = dp(2);
		layoutParams.rightMargin =  dp(2);
        settings.setBackgroundColor(Color.rgb(0,116,186));
        settings.setText("CLOSE");  
		settings.setTextColor(-1);
		settings.setTypeface(null,Typeface.NORMAL);    
        settings.setTextSize(15.0f);
        settings.setGravity(17);
        android.graphics.drawable.GradientDrawable
		DFIABBIf2 = new android.graphics.drawable.GradientDrawable();
        DFIABBIf2.setColor(0);
        DFIABBIf2.setCornerRadius(10);
        DFIABBIf2.setStroke(2, -1);
        settings.setBackground(DFIABBIf2);
        settings.setLayoutParams(layoutParamsA);
		
		
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
		
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mCollapsed.addView(startimage);
		//mCollapsed.addView(closeimage);
        mExpanded.addView(titleText);
        titleText.addView(textView2);
        titleText.addView(settings);
        mExpanded.addView(view1);
        mExpanded.addView(scrollView);
        scrollView.addView(patches);
        mExpanded.addView(view2);
        mFloatingView = rootFrame;
		
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());

        initMenuButton(relativeLayout2, linearLayout);
        CreateMenuList();
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

						if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));

                        mWindowManager.updateViewLayout(mFloatingView, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }


	private boolean hide = false;
	
	private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.GONE);
                    view3.setVisibility(View.VISIBLE);

                }
            });
		
		settings.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    view2.setVisibility(View.VISIBLE);
                    view2.setAlpha(0.95f);
                    view3.setVisibility(View.GONE);

                }
            });
            
		

    }
		
    private void CreateMenuList() {
        String[] listFT = getFeatureList();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("TG_")) {

                addSwitch(str.replace("TG_", ""), new InterfaceBool() {
                        public void OnWrite(boolean z) {
                            Changes(feature, 0);
                        }
                    });
			} else if (str.contains("SB_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
                        public void OnWrite(int i) {
                            Changes(feature, i);
                        }
                    });
		
			} else if (str.contains("CH_")) {
                addCategory(str.replace("CH_", ""));
			} else if (str.contains("CT_")) {
                addCategory2(str.replace("CT_", ""));
            } else if (str.contains("SeekBar_")) {
			} else if (str.contains("SB_")) {
                
                        
                   

            }
        }
    }

    boolean delayed;
	
    public void playSound(Uri uri) {
        if (EnableSounds()) {
            if (!delayed) {
                delayed = true;
                if (FXPlayer != null) {
                    FXPlayer.stop();
                    FXPlayer.release();
                }
                FXPlayer = MediaPlayer.create(this, uri);
                if (FXPlayer != null)
					FXPlayer.setVolume(0.5f, 0.5f);
                FXPlayer.start();

                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            delayed = false;
                        }
                    }, 100);
            }
        }
    }
	
	
	
	public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
        this.expire = paramIntent.getStringExtra("EXPIRY");
        return START_NOT_STICKY; }

    public void onStartCommand(Intent paramIntent) {
        stopSelf();
        try {
            Thread.sleep(80L);
        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(paramIntent);
    }
	
	
	

    public boolean isViewCollapsed() {
        return mFloatingView == null || mCollapsed.getVisibility() == View.VISIBLE;
    }
	
	
	
	
	
	private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }
	
	
	
	
	

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

	
	
	
    public void onDestroy() {
        super.onDestroy();
        View view = mFloatingView;
        if (view != null) {
            mWindowManager.removeView(view);
        }
    }
	
	
	
	

	private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

	
	
	
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

	
	
	
	public void Thread() {
        if (mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {

        } else {
            mFloatingView.setVisibility(View.VISIBLE);
        }
    }
	
	
	
	

    private interface InterfaceBtn {
        void OnWrite();
    }
	
	
	
	

    private interface InterfaceInt {
        void OnWrite(int i);
    }
	
	
	
	

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }
	
	
	
	

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}



